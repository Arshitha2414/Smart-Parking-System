// Fresh Start on Refresh
localStorage.removeItem('parkSmartHistory');
localStorage.removeItem('parkSmartSlots');

// Data Structure
const CONFIG = {
    categories: ['Student', 'Staff', 'Employee', 'College Cab', 'Visitor', 'VIP'],
    types: ['Car', '2W'],
    slotsPerType: 50,
    rates: {
        'Car': 5,
        '2W': 2,
        'Cab': 0,
        'VIP': 0
    }
};

let state = {
    selectedCategory: 'Student',
    selectedType: 'Car',
    balance: parseFloat(localStorage.getItem('parkSmartBalance')) || 1500,
    slots: [], // Will hold approx 550 slots
    history: JSON.parse(localStorage.getItem('parkSmartHistory')) || [],
    viewMode: 'parking', // 'parking' or 'history'
    bookingInProgress: null,
    selectedPaymentMethod: 'Wallet',
    loggedInUser: localStorage.getItem('parkSmartUser') || 'Anonymous'
};

// Initialize Slots
function initSlots() {
    state.slots = [];
    CONFIG.categories.forEach(cat => {
        if (cat === 'College Cab') {
            for (let i = 1; i <= CONFIG.slotsPerType; i++) {
                state.slots.push({
                    id: `CAB-CAB-${i.toString().padStart(3, '0')}`,
                    num: i,
                    category: cat,
                    type: 'Cab',
                    status: 'Available', 
                });
            }
        } else {
            CONFIG.types.forEach(type => {
                for (let i = 1; i <= CONFIG.slotsPerType; i++) {
                    state.slots.push({
                        id: `${cat.substring(0, 3).toUpperCase()}-${type.substring(0, 1).toUpperCase()}-${i.toString().padStart(3, '0')}`,
                        num: i,
                        category: cat,
                        type: type,
                        status: 'Available', 
                    });
                }
            });
        }
    });
    localStorage.setItem('parkSmartSlots', JSON.stringify(state.slots));
}

// Render Logic
function renderGroup() {
    const grid = document.getElementById('slot-grid');
    const filterContainer = document.querySelector('.type-filter');
    
    // College Cab Special Logic
    if (state.selectedCategory === 'College Cab') {
        state.selectedType = 'Cab';
        filterContainer.style.display = 'none';
    } else {
        if (state.selectedType === 'Cab') state.selectedType = 'Car'; // Reset to car if switching from CAB
        filterContainer.style.display = 'flex';
    }

    const filtered = state.slots.filter(s => s.category === state.selectedCategory && s.type === state.selectedType);
    
    document.getElementById('current-category').textContent = `${state.selectedCategory} Parking`;
    document.getElementById('total-count').textContent = filtered.length;
    document.getElementById('free-count').textContent = filtered.filter(s => s.status === 'Available').length;
    
    grid.innerHTML = '';
    
    filtered.forEach(slot => {
        const el = document.createElement('div');
        el.className = `slot ${slot.status === 'Occupied' ? 'occupied' : ''}`;
        
        let slotContent = `
            <span class="slot-num">${slot.num}</span>
            <span class="slot-id-label">${slot.id.split('-').slice(0, 2).join('-')}</span>
            <div class="slot-status"></div>
        `;

        // If occupied, check if it belongs to current user to show details
        if (slot.status === 'Occupied') {
            const hRecord = state.history.find(h => h.slotId === slot.id && h.status === 'Active');
            if (hRecord && hRecord.user === state.loggedInUser) {
                const timeStr = formatTimeLeft(hRecord.expiry, hRecord.timestamp, hRecord.duration);
                slotContent = `
                    <div class="slot-occupied-info">
                        <span class="grid-timer" data-timer-id="${hRecord.id}" data-expiry="${hRecord.expiry}" data-timestamp="${hRecord.timestamp}" data-duration="${hRecord.duration}">${timeStr}</span>
                        <span class="grid-rate">₹${hRecord.amount}</span>
                        <button class="grid-extend-btn" onclick="event.stopPropagation(); initExtension(${hRecord.id})">Extend</button>
                    </div>
                `;
            } else {
                slotContent += `<span class="occupied-label">Occupied</span>`;
            }
        }

        el.innerHTML = slotContent;
        
        if (slot.status === 'Available') {
            el.onclick = () => openBooking(slot);
        }
        
        grid.appendChild(el);
    });
}

// Modal Handlers
const modal = document.getElementById('booking-modal');
const durationSlider = document.getElementById('duration-slider');
const durationVal = document.getElementById('duration-val');
const totalPrice = document.getElementById('total-price');

function openBooking(slot) {
    state.bookingInProgress = slot;
    document.getElementById('modal-slot-id').textContent = slot.id;
    durationSlider.value = 1;
    state.selectedPaymentMethod = 'Wallet';
    document.querySelectorAll('.method-btn').forEach(b => {
        b.classList.remove('active');
        if (b.dataset.method === 'Wallet') b.classList.add('active');
    });

    modal.classList.add('active');
    showStep('step-info');
}

function updateBookingSummary() {
    const hours = durationSlider.value;
    const type = state.selectedCategory === 'College Cab' ? 'Cab' : state.selectedType;
    const isFree = state.selectedCategory === 'VIP' || state.selectedCategory === 'College Cab';
    const rate = isFree ? 0 : CONFIG.rates[type];
    const total = hours * rate;

    durationVal.textContent = `${hours}h`;
    document.getElementById('total-price').textContent = total;
}

function showStep(stepId) {
    document.querySelectorAll('.modal-step').forEach(s => s.classList.add('hidden'));
    document.getElementById(stepId).classList.remove('hidden');
}

// Payment Logic
async function handleConfirm() {
    const hours = durationSlider.value;
    const type = state.selectedCategory === 'College Cab' ? 'Cab' : state.selectedType;
    const isFree = state.selectedCategory === 'VIP' || state.selectedCategory === 'College Cab';
    const rate = isFree ? 0 : CONFIG.rates[type];
    const amount = hours * rate;
    
    if (amount === 0) {
        handlePaid();
        return;
    }

    if (state.selectedPaymentMethod === 'Wallet') {
        if (state.balance < amount) {
            alert('Insufficient wallet balance. Please top up or use QR Code.');
            return;
        }
        // Direct success for wallet
        handlePaid();
    } else {
        // Switch to QR payment step
        showStep('step-payment');
        
        // Generate QR
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=pay-parksmart-${state.bookingInProgress.id}-${amount}`;
        document.getElementById('qr-code').src = qrUrl;
    }
}

function handlePaid() {
    const hours = durationSlider.value;
    const type = state.selectedCategory === 'College Cab' ? 'Cab' : state.selectedType;
    const isFree = state.selectedCategory === 'VIP' || state.selectedCategory === 'College Cab';
    const rate = isFree ? 0 : CONFIG.rates[type];
    const amount = hours * rate;
    
    // Update local state
    state.balance -= amount;
    document.getElementById('balance').textContent = state.balance;
    
    // Mark slot as occupied
    const slotIndex = state.slots.findIndex(s => s.id === state.bookingInProgress.id);
    state.slots[slotIndex].status = 'Occupied';
    localStorage.setItem('parkSmartSlots', JSON.stringify(state.slots));

    // Record in History
    if (state.isExtension) {
        const extIdx = state.history.findIndex(h => h.id === state.extendingRecordId);
        if (extIdx !== -1) {
            const addedMs = parseInt(hours) * 60 * 60 * 1000;
            state.history[extIdx].duration = parseInt(state.history[extIdx].duration) + parseInt(hours);
            state.history[extIdx].amount = parseInt(state.history[extIdx].amount) + parseInt(amount);
            state.history[extIdx].expiry += addedMs;
            state.history[extIdx].time = new Date().toLocaleString() + " (Extended)";
        }
        state.isExtension = false;
    } else {
        const timestamp = Date.now();
        const durationMs = parseInt(hours) * 60 * 60 * 1000;
        const record = {
            id: timestamp,
            user: state.loggedInUser,
            type: state.selectedCategory === 'College Cab' ? 'Cab' : state.selectedType,
            slotId: state.bookingInProgress.id,
            time: new Date().toLocaleString(),
            timestamp: timestamp,
            expiry: timestamp + durationMs,
            duration: hours,
            amount: amount,
            status: 'Active'
        };
        state.history.unshift(record);
    }
    localStorage.setItem('parkSmartHistory', JSON.stringify(state.history));
    
    showStep('step-success');
    renderGroup();
    renderHistory();
}

// Event Listeners
document.querySelectorAll('.nav-item[data-category]').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.selectedCategory = btn.dataset.category;
        switchView('parking');
        renderGroup();
    };
});

document.querySelectorAll('.type-btn').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.selectedType = btn.dataset.type;
        renderGroup();
    };
});

durationSlider.oninput = updateBookingSummary;

document.getElementById('btn-confirm').onclick = handleConfirm;
document.getElementById('btn-paid').onclick = handlePaid;

document.querySelectorAll('.close-modal, .close-modal-btn').forEach(btn => {
    btn.onclick = () => modal.classList.remove('active');
});

document.querySelectorAll('.method-btn').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.method-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.selectedPaymentMethod = btn.dataset.method;
    };
});

// View Switching
function switchView(mode) {
    state.viewMode = mode;
    const parkingView = document.getElementById('view-parking');
    const historyView = document.getElementById('view-history');
    const navItems = document.querySelectorAll('.nav-item');
    
    parkingView.classList.add('hidden');
    historyView.classList.add('hidden');
    navItems.forEach(n => n.classList.remove('active'));

    if (mode === 'parking') {
        parkingView.classList.remove('hidden');
        const activeNav = document.querySelector(`.nav-item[data-category="${state.selectedCategory}"]`);
        if (activeNav) activeNav.classList.add('active');
    } else if (mode === 'history') {
        historyView.classList.remove('hidden');
        document.getElementById('nav-history').classList.add('active');
        renderHistory();
    }
}

document.getElementById('nav-history').onclick = () => switchView('history');

function formatTimeLeft(expiry, timestamp, duration) {
    let target = expiry;
    
    // Fix for older records missing the 'expiry' property
    if (!target && timestamp && duration) {
        target = timestamp + (parseInt(duration) * 60 * 60 * 1000);
    }
    
    if (!target) return "N/A";

    const remaining = target - Date.now();
    if (remaining <= 0) return "Expired";
    
    const h = Math.floor(remaining / 3600000);
    const m = Math.floor((remaining % 3600000) / 60000);
    const s = Math.floor((remaining % 60000) / 1000);
    
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

function renderHistory() {
    const body = document.getElementById('history-body');
    const activeHistory = state.history.filter(h => h.status === 'Active' && h.user === state.loggedInUser);
    
    body.innerHTML = activeHistory.map(h => {
        const timeStr = formatTimeLeft(h.expiry, h.timestamp, h.duration);
        const isNearExpiry = h.expiry && (h.expiry - Date.now() < 300000); // Pulse if under 5 min
        
        return `
            <tr>
                <td>${h.user}</td>
                <td>${h.type}</td>
                <td><strong>${h.slotId}</strong></td>
                <td>
                    <span class="timer-badge ${isNearExpiry ? 'pulse' : ''}" data-timer-id="${h.id}" data-expiry="${h.expiry}" data-timestamp="${h.timestamp}" data-duration="${h.duration}">
                        ${timeStr}
                    </span>
                </td>
                <td>₹${h.amount || 0} (${h.duration || 0}h)</td>
                <td>
                    <button class="btn-primary" style="padding: 0.4rem 0.8rem; font-size: 0.7rem;" onclick="initExtension(${h.id})">
                        Extend
                    </button>
                </td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="6" style="text-align:center; padding: 3rem; color: var(--text-muted);">No active bookings</td></tr>';
}

function autoReleaseEngine() {
    let released = false;
    const now = Date.now();
    
    state.history.forEach(h => {
        if (h.status === 'Active' && now >= h.expiry) {
            h.status = 'Completed';
            const slot = state.slots.find(s => s.id === h.slotId);
            if (slot) {
                slot.status = 'Available';
                released = true;
            }
        }
    });

    if (released) {
        localStorage.setItem('parkSmartSlots', JSON.stringify(state.slots));
        localStorage.setItem('parkSmartHistory', JSON.stringify(state.history));
        renderGroup();
        if (state.viewMode === 'history') renderHistory();
    } else {
        // Targeted sync (Zero flicker)
        syncLiveTimers();
    }
}

function syncLiveTimers() {
    // Update labels in both Grid and History without re-rendering everything
    const activeTimers = document.querySelectorAll('[data-timer-id]');
    activeTimers.forEach(el => {
        const expiry = parseInt(el.dataset.expiry);
        const timestamp = parseInt(el.dataset.timestamp);
        const duration = el.dataset.duration;
        
        const newTimeStr = formatTimeLeft(expiry, timestamp, duration);
        if (el.textContent !== newTimeStr) {
            el.textContent = newTimeStr;
            
            // Handle pulse toggle
            if (expiry && (expiry - Date.now() < 300000)) {
                el.classList.add('pulse');
            } else {
                el.classList.remove('pulse');
            }
        }
    });
}

// Global scope for onclick
window.initExtension = (historyId) => {
    const record = state.history.find(h => h.id === historyId);
    if (!record) return;

    // Set state for extension
    state.bookingInProgress = state.slots.find(s => s.id === record.slotId);
    state.isExtension = true;
    state.extendingRecordId = historyId;
    
    // Open modal
    modal.classList.add('active');
    showStep('step-info');
    document.getElementById('modal-slot-id').textContent = record.slotId + " (Extension)";
    durationSlider.value = 1;
    updateBookingSummary();
};

// Login Logic
const loginForm = document.getElementById('login-form');
const loginOverlay = document.getElementById('login-overlay');
const loginError = document.getElementById('login-error');

loginForm.onsubmit = (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Extract name before '@'
    const expectedPassword = email.split('@')[0];
    
    if (password === expectedPassword) {
        state.loggedInUser = expectedPassword;
        localStorage.setItem('parkSmartUser', expectedPassword);
        loginOverlay.classList.add('hidden');
        localStorage.setItem('parkSmartLoggedIn', 'true');
    } else {
        loginError.classList.remove('hidden');
        setTimeout(() => loginError.classList.add('hidden'), 3000);
    }
};

// Check if already logged in - DISABLED for testing/frequent login
// if (localStorage.getItem('parkSmartLoggedIn') === 'true') {
//     loginOverlay.classList.add('hidden');
// }

// Init
initSlots();

// Initial Balance UI
document.getElementById('balance').textContent = state.balance;

// Top Up Logic
document.querySelector('.btn-topup').onclick = () => {
    const amount = prompt("Enter amount to top up (₹):", "500");
    if (amount && !isNaN(amount) && parseFloat(amount) > 0) {
        state.balance += parseFloat(amount);
        localStorage.setItem('parkSmartBalance', state.balance);
        document.getElementById('balance').textContent = state.balance;
        alert(`Success! ₹${amount} added to your wallet.`);
    } else if (amount !== null) {
        alert("Invalid amount. Please enter a valid number.");
    }
};

// Background Engine (Check every 1s for timers, release slots every 5s)
setInterval(autoReleaseEngine, 1000);
renderGroup();
lucide.createIcons();
